# BrandOS AI — Frontend Web Application

React 19 + TypeScript + Vite + Tailwind CSS enterprise dashboard for AI brand compliance, real-time claim inspection, interactive diff applications, and governance analytics.

---

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment (Optional)
```bash
cp .env.example .env
```
By default, Vite proxies all `/api` requests to `http://localhost:5000` (the BrandOS backend server).

### 3. Run Development Server
```bash
npm run dev
```
Open `http://localhost:5173` in your browser.

### 4. Build for Production
```bash
npm run build
```
Build output is generated into the `dist/` directory.

### 5. Lint
```bash
npm run lint
```

---

## Production Deployment (Vercel / Netlify / Cloudflare Pages)
- **Framework Preset:** Vite
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
- **Environment Variables:**
  - `VITE_API_BASE_URL`: URL of your deployed BrandOS backend (e.g. `https://brandos-backend.onrender.com`).
