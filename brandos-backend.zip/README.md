# BrandOS AI — Backend Microservice

Express.js 5 + TypeScript + Google Gemini 3.8 Flash + Supabase PostgreSQL RLS API microservice for automated brand compliance and regulatory guardrails.

---

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
```
*(Runs out-of-the-box in local development fallback mode if external credentials are not set).*

### 3. Run Automated Tests
```bash
npm test
```

### 4. Run AI Diagnostics (Checks Gemini API & Vector Embeddings)
```bash
npm run check:ai
```

### 5. Start Backend Server
- **Development (with hot reload):** `npm run dev`
- **Production:** `npm start`

Server runs on `http://localhost:5000`. Health check: `http://localhost:5000/api/health`.

---

## Database Migrations (Supabase PostgreSQL)
In your Supabase project dashboard, open the SQL Editor and execute:
1. `server/db/migrations/001_initial_schema.sql` (Tables, enums, triggers, seed data)
2. `server/db/migrations/002_rls_policies.sql` (Row Level Security & workspace isolation)
3. Create a Supabase Storage bucket named `brand-guidelines`.

---

## Docker Deployment
```bash
docker build -t brandos-backend .
docker run -p 5000:5000 --env-file .env brandos-backend
```
